import { EventInfo } from './event-info';

describe('EventInfo', () => {
  it('should create an instance', () => {
    expect(new EventInfo()).toBeTruthy();
  });
});
