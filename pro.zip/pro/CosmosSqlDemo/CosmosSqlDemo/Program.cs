﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System;
using System.Threading.Tasks;

namespace CosmosSqlDemo
{
    class Program
    {
        static DocumentClient client;
        static string endPoint;
        static string authKey;
        static void Main(string[] args)
        {
            endPoint = "https://gajanan-coresql.documents.azure.com:443/";
            authKey = "PClB1vEK1HWlmZnnLC9xSh4bKvH4aU9hdO8Q8hbNR5iQnycSV2HifOFWgRjgsvXCsWKvVnOWYaVrymACx4a89Q==";
            client = new DocumentClient(new Uri(endPoint), authKey);
            //// Create database
            //CreateDatabaseAsync("eshopdb").Wait();
            ////Create collection
            //CreateProductCollectionAsync("eshopdb", "products", "/Category").Wait();
            ////Create document
            //var product = new { Name = "Mirinda", Category = "Drinks", Price = 50, Quantity = 10 };
            //CreateDocumentAsync("eshopdb", "products", product).Wait();
            //Read document
            readDocumentAsync("eshopdb", "products").Wait();
            Console.ReadKey();

        }

        static async Task CreateDatabaseAsync(string dbName)
        {
            await client.CreateDatabaseIfNotExistsAsync(new Microsoft.Azure.Documents.Database {Id =dbName });

        }

        static async Task CreateProductCollectionAsync(string dbName, string collectionName, string partitionKey)
        {
            DocumentCollection collection = new DocumentCollection();
            collection.Id = collectionName;
            collection.PartitionKey.Paths.Add(partitionKey);

            await client.CreateDocumentCollectionIfNotExistsAsync(UriFactory.CreateDatabaseUri(dbName)
                ,collection
                ,new RequestOptions { OfferThroughput=500});
        }

        static async Task CreateDocumentAsync(string dbName, string collectionName, dynamic item)
        {
            await client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(dbName, collectionName),
                item,
                new RequestOptions { PartitionKey = new PartitionKey(item.Category)
                ,ConsistencyLevel =ConsistencyLevel.ConsistentPrefix});
        }

        static async Task readDocumentAsync(string dbName, string collectionName)
        {


            //var response = await client.ReadDocumentAsync(
            // UriFactory.CreateDocumentUri(dbName, collectionName, documentId),
            // new RequestOptions { PartitionKey = new PartitionKey(partitionKey) }
            // );

            string continuationToken = null;
            do
            {
                var feed = await client.ReadDocumentFeedAsync(
                    UriFactory.CreateDocumentCollectionUri(dbName, collectionName),
                    new FeedOptions { MaxItemCount = 10, RequestContinuation = continuationToken }
                    );
                continuationToken = feed.ResponseContinuation;
                foreach (Document document in feed)
                {
                    Console.WriteLine(document);
                }

            } while (continuationToken != null);
        }
    }
}
