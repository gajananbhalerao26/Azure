﻿using CosmosMongoDemo.Model;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;

namespace CosmosMongoDemo
{
    public class CataLogContext
    {
        private readonly IMongoDatabase database;

        public CataLogContext()
        {
            var connectionString = "";
            var databaseName = "";
            MongoClientSettings clientSettings = MongoClientSettings.FromConnectionString(connectionString);
            MongoClient client = new MongoClient();
            if (client != null)
            {
                this.database = client.GetDatabase(databaseName);
            }
        }

        public IMongoCollection<CatalogItem> CatalogItems
        {
            get { return this.database.GetCollection(<CatalogItem> ("CatalogItems")};
            
        }
    }
}
