﻿using CosmosMongoDemo.Model;
using System;

namespace CosmosMongoDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            cataLogContext = new CataLogContext();
            CatalogItem item = new CatalogItem
            {
                Name = "Oraange",
                Price = 80,
                Quantity = 10,
                Vendors = new System.Collections.Generic.List<Vendor>
                {
                    new Vendor{ Id = 1, name = "AB"},
                    new Vendor{ Id = 2, name = "VG"},
                    new Vendor{ Id = 3, name = "XY"}
                }
            };

            InsertItem(item);

            
        }

        private static void InsertItem(CatalogItem item)
        {
            CataLogContext.
        }
    }
}
